import 'dart:async';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';

class PlayerHomePage extends StatefulWidget {
  const PlayerHomePage({super.key});

  @override
  State<PlayerHomePage> createState() => _PlayerHomePageState();
}

class _PlayerHomePageState extends State<PlayerHomePage> {
  late final Player _player;
  late final VideoController _videoController;
  StreamSubscription<bool>? _playingSubscription;
  StreamSubscription<Duration>? _positionSubscription;
  StreamSubscription<Duration>? _durationSubscription;
  StreamSubscription<String>? _errorSubscription;

  final TextEditingController _urlController = TextEditingController();
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;
  bool _isPlaying = false;
  bool _isBusy = false;
  bool _isFullscreen = false;
  double _volume = 100;
  double _speed = 1;
  String _status = 'Choose a video or enter a media URL';
  String _currentTitle = 'Nothing playing';

  @override
  void initState() {
    super.initState();
    _player = Player();
    _videoController = VideoController(_player);

    _playingSubscription = _player.stream.playing.listen((value) {
      if (mounted) setState(() => _isPlaying = value);
    });
    _positionSubscription = _player.stream.position.listen((value) {
      if (mounted) setState(() => _position = value);
    });
    _durationSubscription = _player.stream.duration.listen((value) {
      if (mounted) setState(() => _duration = value);
    });
    _errorSubscription = _player.stream.error.listen((value) {
      if (mounted && value.isNotEmpty) {
        setState(() => _status = 'Playback error: $value');
      }
    });
  }

  @override
  void dispose() {
    _playingSubscription?.cancel();
    _positionSubscription?.cancel();
    _durationSubscription?.cancel();
    _errorSubscription?.cancel();
    _urlController.dispose();
    _player.dispose();
    super.dispose();
  }

  Future<void> _openLocalFile() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.video,
        allowMultiple: false,
        withData: false,
      );
      if (result == null || result.files.isEmpty) return;
      final path = result.files.single.path;
      if (path == null || path.isEmpty) {
        _showMessage('Could not access this file. Try choosing it again.');
        return;
      }
      await _openMedia(path, result.files.single.name);
    } catch (error) {
      _showMessage('Could not open file: $error');
    }
  }

  Future<void> _openUrl() async {
    final url = _urlController.text.trim();
    final uri = Uri.tryParse(url);
    if (uri == null ||
        !(uri.scheme == 'http' || uri.scheme == 'https') ||
        uri.host.isEmpty) {
      _showMessage('Enter a valid HTTP or HTTPS media URL.');
      return;
    }
    await _openMedia(url, uri.pathSegments.isEmpty ? url : uri.pathSegments.last);
  }

  Future<void> _openMedia(String source, String title) async {
    setState(() {
      _isBusy = true;
      _status = 'Opening media…';
      _currentTitle = title;
      _position = Duration.zero;
      _duration = Duration.zero;
    });
    try {
      await _player.open(Media(source));
      if (mounted) {
        setState(() {
          _status = 'Playing $title';
          _isBusy = false;
        });
      }
    } catch (error) {
      if (mounted) {
        setState(() {
          _status = 'Unable to play this media: $error';
          _isBusy = false;
        });
      }
    }
  }

  Future<void> _togglePlayPause() async {
    if (_isPlaying) {
      await _player.pause();
    } else {
      await _player.play();
    }
  }

  Future<void> _toggleFullscreen() async {
    final next = !_isFullscreen;
    setState(() => _isFullscreen = next);
    if (next) {
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
      await SystemChrome.setPreferredOrientations(
        const [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight],
      );
    } else {
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      await SystemChrome.setPreferredOrientations(
        const [DeviceOrientation.portraitUp, DeviceOrientation.landscapeLeft,
          DeviceOrientation.landscapeRight],
      );
    }
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  String _time(Duration value) {
    final total = value.inSeconds;
    final hours = total ~/ 3600;
    final minutes = (total % 3600) ~/ 60;
    final seconds = total % 60;
    if (hours > 0) {
      return '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
    }
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  Future<void> _setSpeed(double speed) async {
    setState(() => _speed = speed);
    await _player.setRate(speed);
  }

  Future<void> _setVolume(double volume) async {
    setState(() => _volume = volume);
    await _player.setVolume(volume);
  }

  @override
  Widget build(BuildContext context) {
    final maxMs = _duration.inMilliseconds > 0
        ? _duration.inMilliseconds.toDouble()
        : 1.0;
    final positionMs = _position.inMilliseconds
        .clamp(0, maxMs.toInt())
        .toDouble();

    return Scaffold(
      appBar: _isFullscreen
          ? null
          : AppBar(
              leading: const Padding(
                padding: EdgeInsets.only(left: 12),
                child: Icon(Icons.play_circle_fill, color: Color(0xFFFF7A18), size: 30),
              ),
              title: const Text(
                'Seoary-Media Player',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18),
              ),
              actions: [
                IconButton(
                  tooltip: 'Open video',
                  onPressed: _openLocalFile,
                  icon: const Icon(Icons.folder_open),
                ),
                const SizedBox(width: 6),
              ],
            ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Container(
                width: double.infinity,
                color: Colors.black,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Video(
                      controller: _videoController,
                      controls: NoVideoControls,
                      fit: BoxFit.contain,
                    ),
                    if (_isBusy)
                      const CircularProgressIndicator(color: Color(0xFFFF7A18)),
                    if (!_isPlaying && !_isBusy && _duration == Duration.zero)
                      IgnorePointer(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.movie_outlined,
                                size: 64, color: Colors.white.withValues(alpha: 0.28)),
                            const SizedBox(height: 12),
                            Text(
                              'Your media, your player',
                              style: TextStyle(
                                color: Colors.white.withValues(alpha: 0.78),
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    Positioned(
                      left: 12,
                      right: 12,
                      bottom: 8,
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              _currentTitle,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 12, color: Colors.white70),
                            ),
                          ),
                          IconButton(
                            tooltip: _isFullscreen ? 'Exit fullscreen' : 'Fullscreen',
                            onPressed: _toggleFullscreen,
                            color: Colors.white,
                            icon: Icon(_isFullscreen
                                ? Icons.fullscreen_exit
                                : Icons.fullscreen),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            if (!_isFullscreen) ...[
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
                child: Row(
                  children: [
                    Text(_time(_position), style: const TextStyle(fontSize: 12)),
                    Expanded(
                      child: Slider(
                        value: positionMs,
                        min: 0,
                        max: maxMs,
                        onChanged: _duration == Duration.zero
                            ? null
                            : (value) => _player.seek(
                                  Duration(milliseconds: value.round()),
                                ),
                      ),
                    ),
                    Text(_time(_duration), style: const TextStyle(fontSize: 12)),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      tooltip: 'Stop',
                      onPressed: () async {
                        await _player.stop();
                        setState(() {
                          _position = Duration.zero;
                          _status = 'Stopped';
                        });
                      },
                      icon: const Icon(Icons.stop_circle_outlined),
                    ),
                    IconButton(
                      tooltip: 'Back 10 seconds',
                      onPressed: () => _player.seek(
                        Duration(
                          milliseconds: (_position.inMilliseconds - 10000)
                              .clamp(0, _duration.inMilliseconds)
                              .toInt(),
                        ),
                      ),
                      icon: const Icon(Icons.replay_10),
                    ),
                    const SizedBox(width: 8),
                    FilledButton(
                      onPressed: _togglePlayPause,
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xFFFF7A18),
                        foregroundColor: Colors.black,
                        shape: const CircleBorder(),
                        padding: const EdgeInsets.all(15),
                      ),
                      child: Icon(_isPlaying ? Icons.pause : Icons.play_arrow, size: 28),
                    ),
                    const SizedBox(width: 8),
                    IconButton(
                      tooltip: 'Forward 10 seconds',
                      onPressed: () => _player.seek(
                        Duration(
                          milliseconds: (_position.inMilliseconds + 10000)
                              .clamp(0, _duration.inMilliseconds)
                              .toInt(),
                        ),
                      ),
                      icon: const Icon(Icons.forward_10),
                    ),
                    PopupMenuButton<double>(
                      tooltip: 'Playback speed',
                      initialValue: _speed,
                      onSelected: _setSpeed,
                      itemBuilder: (context) => const [
                        PopupMenuItem(value: 0.5, child: Text('0.5×')),
                        PopupMenuItem(value: 0.75, child: Text('0.75×')),
                        PopupMenuItem(value: 1, child: Text('1.0× (Normal)')),
                        PopupMenuItem(value: 1.25, child: Text('1.25×')),
                        PopupMenuItem(value: 1.5, child: Text('1.5×')),
                        PopupMenuItem(value: 2, child: Text('2.0×')),
                        PopupMenuItem(value: 3, child: Text('3.0×')),
                      ],
                      child: Padding(
                        padding: const EdgeInsets.all(10),
                        child: Text('${_speed}×', style: const TextStyle(fontSize: 12)),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                child: Row(
                  children: [
                    Icon(_volume == 0 ? Icons.volume_off : Icons.volume_up, size: 20),
                    Expanded(
                      child: Slider(
                        value: _volume,
                        min: 0,
                        max: 100,
                        onChanged: _setVolume,
                      ),
                    ),
                    SizedBox(
                      width: 52,
                      child: Text('${_volume.round()}%',
                          textAlign: TextAlign.end,
                          style: const TextStyle(fontSize: 12)),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 0, 14, 8),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _urlController,
                        keyboardType: TextInputType.url,
                        textInputAction: TextInputAction.go,
                        onSubmitted: (_) => _openUrl(),
                        decoration: InputDecoration(
                          hintText: 'Open network media URL (https://…)',
                          prefixIcon: const Icon(Icons.link),
                          filled: true,
                          fillColor: const Color(0xFF1B1D22),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide.none,
                          ),
                          contentPadding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton.filled(
                      tooltip: 'Play URL',
                      onPressed: _openUrl,
                      icon: const Icon(Icons.play_arrow),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    _status,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12,
                      color: _status.startsWith('Playback error') ||
                              _status.startsWith('Unable')
                          ? Colors.redAccent
                          : Colors.white60,
                    ),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
