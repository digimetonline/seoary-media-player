# Seoary-Media Player (Android MVP)

A Flutter + media_kit starter for the Seoary-Media Player, based on the Universal Video Player PRD.

## MVP included
- Local media file selection using Android's system file picker
- Play/pause, seek, volume, playback speed, fullscreen
- Open a direct media URL
- Practical VLC-inspired dark UI
- Clear playback error/status messages

## Not included yet
Subtitles, audio-track selection, resume position, recent history, media info, playlists, advanced gestures, HLS/DASH edge-case testing, and desktop packaging are next milestones.

## Requirements
- Flutter SDK (stable)
- Android Studio / Android SDK
- Android device or emulator (a real device is recommended for codec testing)

## Run
1. Install Flutter and Android Studio.
2. Unzip this project.
3. In the project folder run:
   ```bash
   flutter pub get
   flutter doctor
   flutter run
   ```
4. To build a release APK:
   ```bash
   flutter build apk --release
   ```
   For Play Console, build an Android App Bundle:
   ```bash
   flutter build appbundle --release
   ```

## Notes
- Android file selection is handled by `file_picker`; the selected file is passed to `media_kit` as a local path.
- Playback compatibility depends on the codecs and platform libraries available for the device. No player can guarantee every possible format.
- Check package versions on pub.dev before production release. Keep `media_kit`, `media_kit_video`, and the Android media-kit library compatible.
- The project uses `media_kit_libs_android_video` for Android video playback support.


## Quick Windows APK build

1. Install Flutter stable and Android Studio.
2. Open the extracted project folder.
3. Double-click `build_apk_windows.bat`.
4. If the build succeeds, `Seoary-Media-Player.apk` will appear in the project root.

If the script fails, open Command Prompt in this folder and run `flutter doctor`; resolve the reported Android SDK/licence issues, then run the script again. The script is a convenience wrapper; it cannot guarantee a successful build on every machine or substitute for testing on a real phone.
