@echo off
setlocal
title Seoary-Media Player APK Builder

echo.
echo ============================================
echo   Seoary-Media Player - Android APK Builder
echo ============================================
echo.

where flutter >nul 2>nul
if errorlevel 1 (
  echo ERROR: Flutter was not found in PATH.
  echo Install Flutter stable and Android Studio, then reopen this terminal.
  echo Guide: https://docs.flutter.dev/get-started/install/windows
  pause
  exit /b 1
)

echo [1/4] Checking Flutter...
flutter --version
if errorlevel 1 goto failed

if not exist android\app\build.gradle if not exist android\app\build.gradle.kts (
  echo [2/4] Generating Android platform files...
  flutter create --platforms=android .
  if errorlevel 1 goto failed
) else (
  echo [2/4] Android platform files already exist.
)

echo [3/4] Installing Flutter dependencies...
flutter pub get
if errorlevel 1 goto failed

echo Checking Android INTERNET permission for URL streaming...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p='android/app/src/main/AndroidManifest.xml'; if (Test-Path $p) { $s=Get-Content $p -Raw; if ($s -notmatch 'android.permission.INTERNET') { $s=$s -replace '<manifest([^>]*)>', '<manifest$1>' + [Environment]::NewLine + '    <uses-permission android:name=\"android.permission.INTERNET\" />'; Set-Content -Path $p -Value $s -Encoding UTF8; Write-Host 'Added INTERNET permission.' } else { Write-Host 'INTERNET permission already present.' } } else { Write-Host 'WARNING: AndroidManifest.xml not found.' }"

echo [4/4] Building release APK...
flutter build apk --release
if errorlevel 1 goto failed

if not exist build\app\outputs\flutter-apk\app-release.apk (
  echo ERROR: Flutter build command finished but APK was not found.
  goto failed
)

copy /Y build\app\outputs\flutter-apk\app-release.apk Seoary-Media-Player.apk >nul
echo.
echo SUCCESS: APK created:
echo %CD%\Seoary-Media-Player.apk
echo.
echo Copy Seoary-Media-Player.apk to your Android phone and open it to install.
echo If Android blocks installation, allow "Install unknown apps" for the app you used to open it.
pause
exit /b 0

:failed
echo.
echo BUILD FAILED. Read the error above. Common fixes:
echo 1. Run flutter doctor and install missing Android SDK components.
echo 2. Accept licenses with: flutter doctor --android-licenses
echo 3. Check the dependency/version error shown above.
pause
exit /b 1
