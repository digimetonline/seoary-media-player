# Android setup notes

Flutter's generated Android project files vary by Flutter version. Create the Android scaffold if it is not present:

```bash
flutter create --platforms=android .
```

Then check `android/app/build.gradle` or `android/app/build.gradle.kts` and set the minimum SDK to at least 23 if required by the selected media_kit version. Keep the generated Gradle and Kotlin versions compatible with your installed Flutter SDK.

The MVP uses Android's system document picker via `file_picker`; it should not require broad storage permissions for the user-selected file. Network URL playback requires internet permission. Flutter templates commonly include it; verify `android/app/src/main/AndroidManifest.xml` contains:

```xml
<uses-permission android:name="android.permission.INTERNET" />
```

Do not add broad storage permissions unless a later feature truly needs them.
