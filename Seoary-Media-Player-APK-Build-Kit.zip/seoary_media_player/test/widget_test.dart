import 'package:flutter_test/flutter_test.dart';
import 'package:seoary_media_player/main.dart';

void main() {
  testWidgets('shows Seoary-Media Player home screen', (tester) async {
    await tester.pumpWidget(const SeoaryMediaPlayerApp());
    expect(find.text('Seoary-Media Player'), findsOneWidget);
    expect(find.text('Your media, your player'), findsOneWidget);
  });
}
