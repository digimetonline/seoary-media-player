import 'package:flutter/material.dart';
import 'package:media_kit/media_kit.dart';

import 'player_home_page.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  MediaKit.ensureInitialized();
  runApp(const SeoaryMediaPlayerApp());
}

class SeoaryMediaPlayerApp extends StatelessWidget {
  const SeoaryMediaPlayerApp({super.key});

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFFFF7A18);
    return MaterialApp(
      title: 'Seoary-Media Player',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: accent,
          brightness: Brightness.dark,
          surface: const Color(0xFF17191D),
        ),
        scaffoldBackgroundColor: const Color(0xFF101114),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF17191D),
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
        sliderTheme: const SliderThemeData(
          activeTrackColor: accent,
          thumbColor: accent,
          inactiveTrackColor: Color(0xFF55575D),
        ),
      ),
      home: const PlayerHomePage(),
    );
  }
}
